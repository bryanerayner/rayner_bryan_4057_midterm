<?php
//The cupcake data
//make this data into an include of its own so both pages share the same information
$cupcakes =  array( array("id"=>1, "name"=>"Chocolate Fever", "price"=>"2.85", "description"=>"So full of chocolate it will drive you crazy."), 
                    array("id"=>2, "name"=>"Cherry Bomb", "price"=>"3.15", "description"=>"Chocolate cake filled with bing cherrys and topped with whipped chocolate."),
                    array("id"=>3, "name"=>"Vanilla Bean", "price"=>"2.85", "description"=>"White light cake topped with vanilla bean cream icing."),
                    array("id"=>4, "name"=>"Chocolate Fudge", "price"=>"3.30", "description"=>"Think dense dark chocolate cake with dark chocolate fudge icing."),
                    array("id"=>5, "name"=>"Caramel Nut", "price"=>"2.75", "description"=>"Chocolate cake filled with walnuts and topped with caramel."),
                    array("id"=>6, "name"=>"Chocolate Coconut", "price"=>"3.10", "description"=>"Rich moist chocolate made with coconut milk and filled with real coconut."),
                    array("id"=>7, "name"=>"Raspberry Swirl", "price"=>"3.20", "description"=>"Vanilla cake with raspberry swirls topped with a light raspberry icing."),
                    array("id"=>8, "name"=>"Strawberry Lime", "price"=>"3.05", "description"=>"Pink strawberry cake topped with a light lime icing.") );

?>
        <footer class="footer">
        	<p>&copy; 2013 Cupcakes!</p>
        </footer>
</body>
</html>